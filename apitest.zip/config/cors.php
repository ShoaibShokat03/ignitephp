<?php
return [
    'allow_all_origins' => true,
    'allowed_origins' => [
        'https://example.com',
        'https://anotherdomain.com',
        // Add any allowed origins here
    ],
];
